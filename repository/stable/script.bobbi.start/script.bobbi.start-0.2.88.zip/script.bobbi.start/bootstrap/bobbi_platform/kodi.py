"""Runtime adapters. Kodi modules are imported only inside the Kodi entrypoint."""
import json


def rpc(method, params=None):
    import xbmc
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {},
    })))
    if 'error' in response or 'result' not in response:
        raise RuntimeError('Kodi RPC failed: ' + method)
    return response['result']


def make_item(url, data):
    import xbmcgui
    item = xbmcgui.ListItem(label=data.get('title', 'bobbi'), path=url)
    item.setProperty('IsPlayable', 'true')
    if data.get('title'):
        item.getVideoInfoTag().setTitle(data['title'])
    tag = item.getVideoInfoTag()
    tv = data.get('tv_data') or {}
    for key, setter in (('season', 'setSeason'), ('episode', 'setEpisode')):
        value = tv.get(key)
        if type(value) is int and value >= 0:
            getattr(tag, setter)(value)
    art = {key: data[key] for key in ('poster', 'fanart', 'thumb')
           if isinstance(data.get(key), str) and data[key]}
    if art:
        item.setArt(art)
    subtitles = data.get('subtitles_path') or []
    if isinstance(subtitles, list) and subtitles:
        item.setSubtitles(subtitles)
    request = data.get('request_id')
    if request:
        item.setProperty('bobbi.standard.request', request)
        tag.setUniqueID(request, 'bobbi_request')
    if data.get('_pan_file'):
        position = data.get('_file_resume_position', 0)
        if type(position) in (int, float) and 0 < position <= 864000:
            item.setProperty('StartOffset', str(position))
    # Do not override global audio/HDR/codec/refresh-rate/OSD settings. Original
    # language and Chinese preference are a first-run user-confirmed setting.
    return item


def standard_handoff(identity, handle, ready=lambda: True):
    import xbmc
    import xbmcplugin
    from .playback import Handoff
    return Handoff(identity, handle, xbmcplugin.setResolvedUrl, xbmc.Player().play, make_item, ready)
