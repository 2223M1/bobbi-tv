# PR #1 / CE2006：独立审查

## 判定与冻结

建议继续保留 CE2006，修复本文两个代码问题后再推进候选；保持 Draft，不批准稳定发行。
这轮不是1909的原地踏步：上轮18项身份反例已独立全过，同源字幕、部分字体激活和同版115续播已有新增证据。

- PR头：c62e816607f3ef13d6763950bcdd4175bde6044c。
- tree：5ea37161349d28a1170275173d4677c0b46b8fe8。
- 增量父提交：f1495ef656d950bf33f7b3cabda86d27e45f5718。
- 上轮源码：cdf0c487c3640228cfe5844a3af2813e5367aa3b。
- PR目标main：71ea55831c58f26cd6ab89ff5331b86ae33ca869。

仓库内的最后设备回执是已安装2026102006、core0.1.11、原F9、无播放器、影院首页，
不是上轮1909停用后的旧系统状态。它是历史交接回执，本审查没有实时连接盒子。
当前项目仍私有；Windows/Android暂停。本轮不操作设备、账号、云任务、远端分支或PR。

## R01 / P1：带修订号的范围终点漏判

位置：addons/script.module.bobbi.core/lib/bobbi_core/filename_semantics.py:21–24、46–50。
调用点：torrent_episode_matching.py:29–37；torrent_selection.py:177–201；release_identity.py 的 bound_family。

MULTI的纯数字终点要求后面不是字母数字。遇到02v2时，v使该分支失败，range_after返回空。
于是一个明确声明两集的文件，反而成为“没有范围后缀”的单集。

目标S1E1时的冻结结果：

| 文件 | 当前family | 无绑定selector | hash绑定selector |
|---|---|---|---|
| Audit.Show.S01E01-02v2.1080p.HEVC.mkv | 接受 | 选中 | 选中 |
| Audit.Show.S01E01+02v2.1080p.HEVC.mkv | 接受 | 选中 | 选中 |
| Audit.Show.S01E01&02v10.1080p.HEVC.mkv | 接受 | 选中 | 选中 |
| Audit.Show.1x01-02v2.1080p.HEVC.mkv | 接受 | 选中 | 选中 |
| Audit.Show.S01E01v2-02v2.1080p.HEVC.mkv | 接受 | 选中 | 选中 |

前四个basename的旧bound_family拒绝，是新增回归；两端均带revision的写法旧版也接受，是仍未覆盖的既存缺口。
标准01-02及01-E02v2被拒，单集01v2、-1080p、尺寸和CRC控制通过。

独立运行的是逐字节核对的实际纯模块，不是另写的简化选择算法。
没有实际Kodi开播，也没有声称所有额外provider保护都会绕过；足以证明这里不能返回精确单集肯定结论。
上层未进入手选时会沿AUTO_VERIFIED路径处理，不能把这个错误归因于用户明确选择。

最小修复：统一语法应消费范围终点的revision后再判断边界；保持技术字段不成为范围、单集v2/v10与组/画质指纹。
附参考补丁在临时副本通过旧18+新14场景。还需接入全仓和真实selector→准备→续播回归；不直接部署。

## R02 / P2：正常浮点下载速度被诊断过滤

位置：addons/plugin.video.bobbi.torrent/lib/bobbi_torrent/resolver.py:288–292。

buffer_snapshot对所有字段一律type(v) is int。TorrServer的DownloadSpeed是float64，
正常例如98409.04851425653会在JSON解码后成为float，被静默删掉；0.0同样消失。
整数控制仍正常，所以只使用整数假数据的测试容易漏过。

本包执行原赋值语句摘录，8种输入中6满足、2未满足。不冒充完整resolver网络测试。
这个缺陷不会让BT变慢，但让“已经定位、等待的是供数”的诊断缺少关键值，影响下一轮归因。

修复：在后端适配边界把有限、非负、上限内的int/float归一为整数B/s，拒绝bool、NaN、Infinity、负数和字符串。
未知值保持缺失，真实零保留为0。entry.failure_log可继续使用有界整数合同。
不要把torrent总缓存当作所选文件连续可读字节。

## D01 / 集成阻断：冲突导致PR工作流不运行

本轮GitHub原始API：draft=true、mergeable=false、rebaseable=false、mergeable_state=dirty。
查询当前head Actions和pull_request事件运行，均为0条。
verify.yml仅push main与pull_request触发，因此候选分支push不会运行；有合并冲突时GitHub不运行pull_request工作流。
这是已成立的触发阻断，不是测试已经跑过但失败，也不证明不存在其它仓库级限制。

在独立集成工作树同步目标main、逐项解决冲突并重跑；不覆盖原dirty工作区、不强推main、不合并或发布。
若授权维护分支，可增加只读、无发布secret的codex/** push检查，使草稿/冲突期间也能验证head；
它不替代解决冲突后的合并结果验证。不要为了亮绿灯改成pull_request_target执行不受信任PR代码。
远端应保存三类隔离测试进程和两次构建比较的真实退出码，区分测试head与测试合并结果。

## 已改善、不要退回的部分

1. filename_semantics统一到family与选择器，上轮18项全部通过；继续这一结构，不整体回滚旧正则。
2. USER_CONFIRMED_FILE与AUTO_VERIFIED_FILE分离；owner不能重绑升级证据，自动准备入口有当前actor快照检查。
   已读对应源码和作者定向测试；本轮未重跑整套Kodi/mock集成测试。
3. 终态NATURAL_EOF才标completed；错误/未知保留续看，自动后继与末尾菜单分开。
4. 零时长ASS事件仅从分析投影跳过，原字幕字节不重写；同版RAR字体使用既有受限解压器。
5. 有缺失字体时仍激活已核验的匹配字体，同时保持inputs_complete=false；不应把候选存在、文件激活当作渲染认证。
6. 渐进传输已有实现与比较，默认block未改。OddTaxi渐进仍有启动缓存，因此不应宣布它普遍优于block。

## 原始回执交叉核对

- final-health-2006.json：generation2006、原F9、账号epoch1、候选皮肤首页、无播放器；准备由新host拥有。
- ce-continuation-flip_flappers-1792479373354999600.json：实际E2、全屏12005、原1080p HEVC、准确字幕hash、subtitleenabled=true、无caching采样；
  ordered_eof_handoff_log=true。终态在child启动后不留在live状态，不能因terminal={}单独否认交接。
- 维护文档报告2006 Flip E1约3.54s到AV、约35.99s稳定窗、五字体两缺失，人工开关未被覆盖。
  这些数值是作者历史回执/文档记录，不是本轮实播。
- 同作115成功不能抹去之前BT路径失败；旧作回归不算新作覆盖。
- OddTaxi启动buffer、字幕底部裁切、空白设备、第二真实账号和物理音画仍开放。

## 范围与计数

本轮实际：旧18项18过；14命名场景9过5失败（每场景同时查三个真实路径，不按42另计）；
8个诊断语句场景6过2失败。合计40个场景33满足7未满足，7失败对应两组代码问题。
控制例语义有重叠，重复执行不计新增覆盖。六份当前完整源码逐Git blob核对。
参考语法补丁只证明旧18与新14的局部改善，不是完成全部整改。

未做：整仓2512项、六个skip的实际能力、签名发行包逐文件、真实HTTP传输矩阵、设备/VPS/云任务、
原生构建、Windows/Android、空白机、换号、电视字幕视觉验收。PR累计2253文件包含前轮档案，不能声称逐份全审。

## 证据入口

仓库冻结入口：docs/CE2006-WEB-REVIEW-20261020.md；docs/ce-remediation-20261020.md；
review-evidence/ce-20261020/final-health-2006.json；
review-evidence/ce-continuation-flip_flappers-1792479373354999600.json；
.github/workflows/verify.yml；tests/test_ce_manual_and_completion.py。
本包运行结果：evidence/independent-run1/RESULT.json及相邻逐场景JSON。
外部协议说明：GitHub官方docs的events-that-trigger-workflows/pull_request；
YouROK/TorrServer的server/torr/torrent.go（DownloadSpeed float64）。
