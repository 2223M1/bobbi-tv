#!/usr/bin/env python3
"""Offline frozen-source audit. Does not contact devices, cloud services or GitHub.
Exit 1 denotes unsatisfied behavior assertions; 2 denotes an execution error.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace, ModuleType

BASE = Path(__file__).resolve().parent


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def reset_core(root: Path) -> None:
    for name in tuple(sys.modules):
        if name == 'bobbi_core' or name.startswith('bobbi_core.'):
            del sys.modules[name]
    package = ModuleType('bobbi_core')
    package.__path__ = [str(root)]
    sys.modules['bobbi_core'] = package


def previous18(root: Path) -> dict:
    reset_core(root)
    spec = importlib.util.spec_from_file_location('previous_identity_probe', BASE/'tests/previous_identity_probe.py')
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module.run(root)


NAMES = [
    ('range-end-revision', 'Audit.Show.S01E01-02v2.1080p.HEVC.mkv', False),
    ('plus-end-revision', 'Audit.Show.S01E01+02v2.1080p.HEVC.mkv', False),
    ('and-end-revision', 'Audit.Show.S01E01&02v10.1080p.HEVC.mkv', False),
    ('both-end-revisions', 'Audit.Show.S01E01v2-02v2.1080p.HEVC.mkv', False),
    ('nxm-end-revision', 'Audit.Show.1x01-02v2.1080p.HEVC.mkv', False),
    ('plain-range-control', 'Audit.Show.S01E01-02.1080p.HEVC.mkv', False),
    ('labelled-range-control', 'Audit.Show.S01E01-E02v2.1080p.HEVC.mkv', False),
    ('both-labelled-control', 'Audit.Show.S01E01v2-E02v2.1080p.HEVC.mkv', False),
    ('single-repair-control', 'Audit.Show.S01E01v2.1080p.HEVC.mkv', True),
    ('resolution-not-endpoint', 'Audit.Show.S01E01-1080p.HEVC.mkv', True),
    ('pixels-not-season', 'Audit.Show.S01E01.[1920x1080.HEVC].mkv', True),
    ('crc-not-episode', 'Audit.Show.S01E01.[7E23ABCD].1080p.mkv', True),
    ('wrong-episode-control', 'Audit.Show.S01E02.1080p.mkv', False),
    ('two-strong-markers', 'Audit.Show.S01E01.S01E02.1080p.mkv', False),
]


def range14(root: Path) -> dict:
    reset_core(root)
    family = importlib.import_module('bobbi_core.release_identity').bound_family
    selector = importlib.import_module('bobbi_core.torrent_selection').select_exact_file
    rows=[]
    binding=json.dumps(dict(media_id='tmdb:42', season=1, episode=1, absolute_episode=1,
                            source_info_hash='a'*40, provenance='catalog-v1'))
    for label, name, expected in NAMES:
        selected={'id':1,'path':name,'length':1000000}
        result={}
        for lane, operation in (
            ('bound_family', lambda:family(name,1,1)),
            ('selector_unbound', lambda:selector([selected],1,1,'Audit Show S01','a'*40,'')),
            ('selector_hash_bound', lambda:selector([selected],1,1,'Audit Show S01','a'*40,binding)),
        ):
            try:
                value=operation()
                result[lane]={'accepted':True,'value':value}
            except ValueError as error:
                result[lane]={'accepted':False,'error':str(error)}
        rows.append(dict(id=label, filename=name, expected_accept=expected, paths=result,
                         passed=all(v['accepted']==expected for v in result.values())))
    return dict(scope='14 filename scenarios; each checks real family + two real selector paths; no Kodi/native playback',
                total=len(rows), passed=sum(r['passed'] for r in rows), failed=sum(not r['passed'] for r in rows), cases=rows)


def previous_comparison() -> dict:
    reset_core(BASE/'source/previous/bobbi_core')
    family=importlib.import_module('bobbi_core.release_identity').bound_family
    rows=[]
    for label,name,expected in NAMES:
        try:
            family(name,1,1)
            accepted=True
        except ValueError:
            accepted=False
        rows.append(dict(id=label,filename=name,accepted=accepted,expected_accept=expected))
    return dict(scope='previous real bound_family only; not an additional current-version suite',cases=rows)


def diagnostic8() -> dict:
    code=compile((BASE/'source/excerpts/resolver_buffer_snapshot.py').read_text(encoding='utf-8'),
                 'resolver.py:288-292 (assignment excerpt)', 'exec')
    rows=[]
    for label,speed,expected in (
        ('fractional-speed',98409.04851425653,98409),
        ('zero-float',0.0,0),
        ('integer-speed',98409,98409),
        ('negative-speed',-1,None),
        ('boolean-is-not-speed',True,None),
        ('nan-is-not-speed',float('nan'),None),
        ('infinity-is-not-speed',float('inf'),None),
        ('string-is-not-speed','98409',None),
    ):
        owner=SimpleNamespace()
        env=dict(self=owner, info=dict(active_peers=2,download_speed=speed),
                 done=11419648,threshold=32000000,file={'length':411570230})
        exec(code,env)
        snapshot=owner.buffer_snapshot
        actual=snapshot.get('download_bps')
        rows.append(dict(id=label,input_repr=repr(speed),expected_download_bps=expected,
                         actual_snapshot=snapshot, passed=actual==expected))
    return dict(scope='exact current snapshot assignment with controlled values; no real torrent or full resolver execution',
                total=len(rows),passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),cases=rows)


def verified_sources() -> list:
    manifest=json.loads((BASE/'SOURCE-PROVENANCE.json').read_text(encoding='utf-8'))
    result=[]
    for record in manifest['files']:
        if record.get('representation') != 'complete original bytes':
            continue
        raw=(BASE/record['file']).read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if actual!=record['git_blob']:
            raise ValueError('Frozen source byte mismatch: '+record['file'])
        result.append(dict(file=record['file'],git_blob=actual,verified=True))
    return result


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True,help='new results directory; existing directories are refused')
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    try:
        sources=verified_sources()
        core=BASE/'source/current/bobbi_core'
        results={'previous18':previous18(core),'ranges14':range14(core),'diagnostics8':diagnostic8()}
        for name,value in results.items():
            write_json(args.output/(name+'.json'),value)
        write_json(args.output/'previous-range-comparison.json',previous_comparison())
        # A proposed ONE-LINE grammar fix is exercised on a temporary copy only.
        with tempfile.TemporaryDirectory(prefix='bobbi-pr1-review-') as temp:
            work=Path(temp)/'bobbi_core'
            shutil.copytree(core,work)
            source=work/'filename_semantics.py'
            old=source.read_text(encoding='utf-8')
            before="r'(?P<plain>\\d+)(?![a-z0-9])))', re.I)"
            after="r'(?P<plain>\\d+)(?:v\\d+)?(?![a-z0-9])))', re.I)"
            if old.count(before)!=1:
                raise ValueError('Reference patch no longer matches frozen source')
            source.write_text(old.replace(before,after),encoding='utf-8')
            patch_results={'previous18':previous18(work),'ranges14':range14(work)}
            write_json(args.output/'reference-patch-results.json',dict(
                scope='local grammar-only reference candidate; not whole repository or device certification',
                results=patch_results,
                all_passed=all(x['failed']==0 for x in patch_results.values())))
        summary=dict(
            head='c62e816607f3ef13d6763950bcdd4175bde6044c',
            current_scenarios=sum(r['total'] for r in results.values()),
            current_satisfied=sum(r['passed'] for r in results.values()),
            current_unsatisfied=sum(r['failed'] for r in results.values()),
            suites={k:{f:v[f] for f in ('total','passed','failed')} for k,v in results.items()},
            byte_verified_sources=sources,
            reference_patch='passes only the 18 previous and 14 range scenarios; speed defect remains unpatched',
            not_run=['full 2512 test suite','release build/signature check','CE/Kodi playback','Windows/Android','device changes','GitHub Actions execution'],
            accounting='Controls overlap semantically across suites; paths and reruns are not multiplied into unique coverage.',
        )
        write_json(args.output/'RESULT.json',summary)
        print(json.dumps(summary,ensure_ascii=False,indent=2))
        return 1 if summary['current_unsatisfied'] else 0
    except Exception as error:
        write_json(args.output/'EXECUTION-ERROR.json',dict(type=type(error).__name__,message=str(error)))
        raise


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(type(error).__name__+': '+str(error),file=sys.stderr)
        raise SystemExit(2)
