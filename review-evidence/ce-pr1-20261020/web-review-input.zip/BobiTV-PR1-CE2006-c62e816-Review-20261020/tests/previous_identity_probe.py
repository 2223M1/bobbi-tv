"""Actual frozen pure modules; not a Kodi or full preparation integration test."""
import importlib
import sys
import types
from pathlib import Path


def run(core):
    package = types.ModuleType('bobbi_core')
    package.__path__ = [str(core)]
    sys.modules['bobbi_core'] = package
    for key in ('release_identity', 'release_names', 'resolution'):
        sys.modules.pop('bobbi_core.' + key, None)
    lib = importlib.import_module('bobbi_core.release_identity')
    rows = []

    def admission(label, name, wanted=True, season=1, episode=1):
        try:
            result = lib.bound_family(name, season, episode)
            accepted, error = True, None
        except ValueError as exc:
            result, accepted, error = None, False, str(exc)
        markers = [dict(text=m[0], season=int(m['season']), episode=int(m['episode']))
                   for pattern in getattr(lib, 'STRONG', ()) for m in pattern.finditer(name)]
        rows.append(dict(id=label, name=name, expected_accept=wanted, actual_accept=accepted,
                         passed=accepted == wanted, family=result, error=error, strong_tokens=markers))

    admission('weak-control', '[Group] Audit Show - 01 [1080p HEVC AAC].mkv')
    admission('strong-control', '[Group] Audit Show S01E01 [1080p HEVC AAC].mkv')
    admission('nxm-control', '[Group] Audit Show 1x01 [1080p HEVC AAC].mkv')
    admission('real-filename-nxm', '[SweetSub&LoliHouse] Flip Flappers - 01 [WebRip 1920x1080 HEVC-yuv420p10 AAC].mkv')
    admission('strong-plus-pixels', '[Group] Audit Show S01E01 [1920x1080 HEVC AAC].mkv')
    admission('nxm-plus-pixels', '[Group] Audit Show 1x01 [1920x1080 HEVC AAC].mkv')
    admission('4k-pixels', '[Group] Audit Show - 01 [3840x2160 HEVC AAC].mkv')
    admission('padded-width', '[Group] Audit Show - 01 [1922x1080 HEVC AAC].mkv')
    admission('pixel-only-is-not-episode', '[Group] Audit Show [1920x1080 HEVC AAC].mkv', False)
    admission('wrong-season', '[Group] Audit Show S02E01 [1080p].mkv', False)
    admission('wrong-episode', '[Group] Audit Show S01E02 [1080p].mkv', False)
    admission('multiple-episodes', '[Group] Audit Show S01E01E02 [1080p].mkv', False)
    admission('title-numbers', '[Group] 86 Part 2 S01E01 [1080p].mkv')
    admission('crc-control', '[Group] Audit Show S01E01 [7E23ABCD] [1080p].mkv')

    for label, a, b, expected in [
        ('same-revision', 'Audit Show S01E01v2 [1080p].mkv', 'Audit Show S01E02v2 [1080p].mkv', True),
        ('different-revision', 'Audit Show S01E01v2 [1080p].mkv', 'Audit Show S01E02v3 [1080p].mkv', False),
        ('different-resolution', 'Audit Show S01E01 [1080p].mkv', 'Audit Show S01E02 [720p].mkv', False),
        ('different-group', '[GroupA] Audit Show S01E01 [1080p].mkv', '[GroupB] Audit Show S01E02 [1080p].mkv', False),
    ]:
        try:
            actual = lib.same_bound_release(a, b, 1, 1)
            error = None
        except ValueError as exc:
            actual, error = None, str(exc)
        rows.append(dict(id=label, names=[a, b], expected_same=expected,
                         actual_same=actual, passed=actual == expected, error=error))
    return dict(scope='actual_pure_modules; real filename plus synthetic controls',
                cases=rows, total=len(rows), passed=sum(r['passed'] for r in rows),
                failed=sum(not r['passed'] for r in rows))
