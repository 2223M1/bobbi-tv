self.buffer_snapshot = {k: v for k, v in dict(
    torrent_preloaded=done, torrent_preload_target=threshold,
    selected_file_bytes=file['length'],
    peers=info.get('active_peers'), download_bps=info.get('download_speed')).items()
    if type(v) is int and 0 <= v <= 512*1024**3}
