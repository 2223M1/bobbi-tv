# Codex：PR1 CE2006 一次连续收敛整改

基准 c62e816607f3ef13d6763950bcdd4175bde6044c，tree 5ea37161349d28a1170275173d4677c0b46b8fe8。
目标main在审查时为71ea55831c58f26cd6ab89ff5331b86ae33ca869；开始时重新读取头，若改变先明确差异。
保持CE范围、原F9和新UI；Windows/Android继续暂停。不覆盖原dirty工作区，不删除历史失败。

读本包REVIEW、FINDINGS、DECISIONS、ACCEPTANCE和SOURCE-PROVENANCE。
仓库内先读docs/CE2006-WEB-REVIEW-20261020.md和docs/ce-remediation-20261020.md。

在附件目录运行：

```text
python -I -B run_review.py --output result-new
```

冻结基线预期40场景33满足7未满足，退出1。脚本会单独测试一个语法参考补丁的临时副本，
不修改用户仓库。参考补丁仅覆盖R01，不是全仓已修复。

在独立候选中连续完成：

1. R01：MULTI要识别带revision的无E前缀范围终点；不同模块共同使用同一语义。
   合集不能因末端v2而升级AUTO_VERIFIED。覆盖S01E01-02v2、+、&、1x01、两端均revision、
   显式E02、普通范围、单集v2/v10、尺寸、CRC、-1080p。保持已有资源键和同版边界。
   可参考0001补丁，但需先git apply --check并独立审查。把本包断言迁入仓库真实模块测试，
   补select_exact_file→准备意图→续播/手选证据权限的端到端层级，不只是单测parse。
2. R02：TorrServer下载速度是可能带小数的number；适配层归一为有界整数B/s。
   拒绝bool/NaN/Inf/负数/字符串，保留真实0，未知不伪报0。对真实float响应shape回归，
   并验证日志/等待提示不会再次删掉该值。速度只是诊断，不是单集已准备证明。
3. D01：当前PR mergeable_state=dirty，PR/head无Actions运行；verify.yml只触发main push和PR。
   在独立集成工作树处理main冲突，保存当前head与diff，不强推main、不合并、不发布。
   远端推送/CI触发只按用户另行明确授权进行。需要草稿head独立CI时添加只读codex/** push，
   不改pull_request_target去运行候选代码，不把head通过代替合并结果通过。
4. 复测现有身份、手选、终态、字幕重检、RAR/部分字体、账号与传输测试。
   仍不默认启用progressive；OddTaxi启动buffer和字幕裁切继续开放，提供最小同源验证方案。

普通实现/离线测试/构建失败保留首败后继续修复，不每项交回Web、不降低断言门槛。
本次审查不新增设备、VPS、云任务、停播/重启/升级或GitHub写入授权。
当前设备交接回执是2006，不要套用1909旧状态或重放旧部署器。

一次交回：实际补丁、原基准与候选commit/tree、完整本地测试退出码、PR/CI真实状态、
已关闭与仍开放问题、回退开关及仍需设备授权的验收。无实机证据不得报告全部修复或稳定发行。
