#!/usr/bin/env python3
"""Verify this planning bundle and run reference-policy tests; never deploy."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def verify_bundle():
    manifest = json.loads((ROOT / "SHA256SUMS.json").read_text(encoding="utf-8"))
    if manifest.get("schema") != 1 or not isinstance(manifest.get("files"), dict):
        raise ValueError("Invalid bundle inventory")
    for name, expected in manifest["files"].items():
        path = ROOT / name
        real = path.resolve(strict=True)
        if ROOT not in real.parents or real != path or not real.is_file():
            raise ValueError("Invalid bundle path: " + name)
        if hashlib.sha256(real.read_bytes()).hexdigest() != expected:
            raise ValueError("Bundle content differs: " + name)
    return len(manifest["files"])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", required=True, type=Path)
    args = p.parse_args()
    if args.output.exists():
        p.error("Output already exists; choose a new directory to preserve prior results")
    count = verify_bundle()
    args.output.mkdir(parents=True)
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_*.py")
    with (args.output / "policy-tests.txt").open("w", encoding="utf-8") as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    outcome = dict(scope="PLANNING_PACKAGE_REFERENCE_ONLY", product_implemented=False,
                   device_tested=False, repository_changed=False, checked_files=count,
                   tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                   skipped=len(result.skipped),
                   status="PLAN_CONTRACT_PASS_NOT_PRODUCT" if result.wasSuccessful() else "PLAN_CONTRACT_FAILED")
    (args.output / "RESULT.json").write_text(json.dumps(outcome, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(outcome, ensure_ascii=False, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as error:
        print("Planning bundle check failed: " + str(error), file=sys.stderr)
        raise SystemExit(2)
