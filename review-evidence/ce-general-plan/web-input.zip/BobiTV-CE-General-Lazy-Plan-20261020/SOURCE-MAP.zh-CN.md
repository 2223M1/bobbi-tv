# 当前真实阻点与修改落点

审查固定在 `da279d45ecf84133f9ac15ddb21a2f18a5f37ba8`。本表是方向纠偏，不是再次宣称整仓逐行审完。

| 当前入口 | 已读事实 | 本次处理 |
|---|---|---|
| `tools/deploy_ce_remote.py:525–595` | 新装/升级仍取running native SHA，不在known_ce_native即抛CE_NATIVE_BUILD_CHANGED | 不再将该专机控制器作为默认新装入口；通用入口按实际API/依赖运行。旧专用恢复保留其检查 |
| 同文件 `upgrade_profile_snapshot():约302–335` | 要求ce-f9和已知native SHA | 通用profile可升级；只有确需旧ABI的操作才选择旧适配器 |
| 同文件开头及migrate_profiles | 固定旧CONFIG/LOGIN、旧插件账号和服务迁移 | 隔离成显式迁移；新用户路径不读取、不复制 |
| `tools/deploy_ce_candidate.py` | 必填外部transport-source，导入另一工作目录device_transport.py | 新装在Kodi内完成，不依赖维护者电脑目录/SSH；远程脚本仅维护用途 |
| `bobbi_platform/capabilities.py` | standard条件包含major==21；native依赖一组私有方法 | 按实际API/导入能力检测，细分增强；API足够的新版本不因版本号拒绝 |
| `lib/native_support.py` / `lib/player.py` | 已有native/stock分派 | 复用它们，避免第三套播放器；改为实际协议探测和能力分派，注意暂时失败缓存 |
| `lib/stock_player.py` | 只允许portable_manual；提交后没有AV/后续观察 | 完成标准播放协调与生命周期，不只改文字或抹异常 |
| `lib/portable.py` | 文档明确prepared/continuation未接；拒绝字幕高级操作、preparedResourceId、directCloudKey等 | 接入共享解析/准备/字幕；具体资源缺配置才限制对应操作，不按模式砍功能 |
| `lib/portable_runtime.py` | native进入owner_loop，stock只host.tick | 给stock接标准事件观察和既有业务协调；不是制造假的native回执 |
| `bobbi_platform/kodi.py` | ListItem仅设置标题、IsPlayable | 承接实际字幕、片源身份、媒体信息及所需播放上下文 |
| `bobbi_core/runtime_paths.py` | 已能profile路径回退，F9目录用已知SHA | 保留局部ABI兼容，不把F9目录适配升级为通用安装前提 |
| `docs/CE-CLEAN-INSTALL-20261020.md` | 仍以受认证F9、手动依赖、SSH、stage/clean-install为正式流程 | 新用户说明改为真正入口；旧流程移到维护者迁移文档 |
| `script.bobbi.setup` / `repository.bobbi` / manifest | 现有入口可复用，组件/官方依赖分离可保留 | 让依赖安装与账号引导自动串联，交付朋友实际可安装的入口 |

## 不应误改

- `known_ce_native` 不必从仓库彻底抹掉：它仍可用于选择特定F9字幕ABI或旧迁移恢复；关键是不再决定所有新用户能否用波比。
- `native_contract_available=false` 不等于不能播放，也不等于能伪造原生协议；应走真实标准端实现。
- 校验发行包签名和组件哈希，与校验陌生盒子的Kodi哈希，是两种不同目的。前者保留，后者不作为通用资格。
- 本次撤回的是产品限制，不撤回上一轮R01/R02已修复的事实，也不把现存缓冲问题扩大成新的设备白名单。

详细URL与读取范围见 `evidence/SOURCES.json`。本轮未读取完整运行包、未实机安装、未运行整仓全部测试。
