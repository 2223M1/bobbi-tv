"""Executable CE product-policy example, NOT an installer or playback adapter.

Environment facts must come from real probes in production. Device names,
previous test coverage and native binary identity are deliberately ignored.
This file has no device, network, process-control or filesystem side effects.
"""
from dataclasses import dataclass, field
from typing import FrozenSet, Tuple


@dataclass(frozen=True)
class Facts:
    coreelec: bool = True
    package_verified: bool = True
    profile_writable: bool = True
    enough_space: bool = True
    standard_api_usable: bool = True
    dependency_state: str = "ready"  # ready / automatically_resolvable / failed
    native_protocol_validated: bool = False
    native_operations: FrozenSet[str] = field(default_factory=frozenset)
    # Diagnostics only: never installation eligibility or UI-warning inputs.
    model: str = ""
    soc: str = ""
    kodi_version: str = ""
    native_sha256: str = ""
    previously_tested: bool = False
    userspace_abi: str = ""
    kernel_arch: str = ""


@dataclass(frozen=True)
class Decision:
    action: str
    next_actions: Tuple[str, ...]
    adapter_plan: Tuple[Tuple[str, str], ...]
    problem: str = ""
    device_notices: Tuple[str, ...] = ()
    device_confirmation_required: bool = False


def decide(facts: Facts) -> Decision:
    """Plan one installation attempt using actual failures, not model identity.

    The adapter plan is an IMPLEMENTATION TARGET, not a capability claim that
    the current repository has already implemented standard subtitle/EOF paths.
    """
    if not isinstance(facts, Facts):
        raise TypeError("Facts required")
    for name in ("coreelec", "package_verified", "profile_writable", "enough_space",
                 "standard_api_usable", "native_protocol_validated"):
        if type(getattr(facts, name)) is not bool:
            raise TypeError("Probe results must be explicit booleans: " + name)
    if facts.dependency_state not in {"ready", "automatically_resolvable", "failed"}:
        raise ValueError("Invalid dependency outcome")
    if not isinstance(facts.native_operations, frozenset):
        raise TypeError("Validated native operations must be a frozenset")

    # Real operation boundaries remain. None of these is a hardware whitelist.
    failures = (
        (not facts.coreelec, "NOT_A_CORELEC_INSTALL_TARGET"),
        (not facts.package_verified, "PACKAGE_INTEGRITY_FAILED"),
        (not facts.profile_writable, "PROFILE_NOT_WRITABLE"),
        (not facts.enough_space, "INSUFFICIENT_SPACE"),
        (not facts.standard_api_usable, "REQUIRED_API_UNAVAILABLE_AFTER_ADAPTATION"),
        (facts.dependency_state == "failed", "DEPENDENCY_INSTALL_FAILED"),
    )
    for failed, problem in failures:
        if failed:
            return Decision("show_actual_error", ("retry_after_specific_fix",), (), problem)

    adapters = tuple((operation, "native" if facts.native_protocol_validated
                      and operation in facts.native_operations else "standard")
                     for operation in ("playback", "subtitles", "continuation"))
    if facts.dependency_state == "automatically_resolvable":
        return Decision("resolve_dependencies", ("install_dependencies", "reprobe", "continue_setup"), adapters)
    return Decision("continue_install", ("install_own_components", "open_cinema", "account_login"), adapters)
