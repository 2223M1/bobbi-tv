#!/usr/bin/env python3
"""Read-only locator for known CE-specific code. Matches are not pass/fail.

A known-native check may legitimately stay in legacy migration and F9 ABI
selection. This report is for tracing the default user path, not mass deletion.
"""
import argparse
import json
from pathlib import Path

TARGETS = {
    "tools/deploy_ce_remote.py": ["known_ce_native", "CE_NATIVE_BUILD_CHANGED", "CE_UPGRADE_NATIVE_ABI", "Addons33.db"],
    "tools/deploy_ce_candidate.py": ["--transport-source", "device_transport.py"],
    "addons/script.module.bobbi.platform/lib/bobbi_platform/capabilities.py": ["major == 21", "native_contract_available", "automatic_continuation"],
    "addons/plugin.video.bobbi/lib/stock_player.py": ["portable_manual", "No on_started"],
    "addons/plugin.video.bobbi/lib/portable.py": ["remain unavailable", "requiresCatalogEpisodeProof", "preparedResourceId", "directCloudKey", "通用版尚未就绪", "通用播放预览"],
    "addons/plugin.video.bobbi/lib/portable_runtime.py": ["if native:", "run_owner_loop", "host.tick()"],
    "addons/script.module.bobbi.core/lib/bobbi_core/runtime_paths.py": ["CE_F9_ROOT", "known_ce_native"],
    "docs/CE-CLEAN-INSTALL-20261020.md": ["F9", "SSH", "transport-source"],
}


def scan(repo):
    root = Path(repo).resolve(strict=True)
    rows = []
    for relative, needles in TARGETS.items():
        path = root / relative
        if not path.exists():
            rows.append(dict(path=relative, state="not_present"))
            continue
        real = path.resolve(strict=True)
        if root not in real.parents or real != path or not real.is_file() or real.stat().st_size > 4 * 1024 * 1024:
            rows.append(dict(path=relative, state="not_read_path_or_size"))
            continue
        content = real.read_text(encoding="utf-8-sig")
        for i, line in enumerate(content.splitlines(), 1):
            hits = [needle for needle in needles if needle in line]
            if hits:
                rows.append(dict(path=relative, line=i, patterns=hits, text=line.strip()))
    return dict(status="LOCATIONS_ONLY_NOT_ACCEPTANCE", root=str(root), matches=rows,
                note="Review real default call paths. Legacy ABI and restoration checks are not blanket-removal targets.")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", required=True, type=Path)
    args = p.parse_args()
    try:
        print(json.dumps(scan(args.repo), ensure_ascii=False, indent=2))
    except (OSError, UnicodeError, ValueError) as error:
        p.exit(2, "Cannot read repository: " + str(error) + "\n")
