"""Tests of the proposed policy only; not tests of completed Bobbi runtime."""
from dataclasses import replace
import unittest
from reference.policy_contract import Facts, decide


class PolicyTests(unittest.TestCase):
    def test_unknown_model_uses_normal_entry(self):
        result = decide(Facts(model="Friends-Unknown-Box"))
        self.assertEqual(result.action, "continue_install")
        self.assertEqual(result.device_notices, ())
        self.assertFalse(result.device_confirmation_required)

    def test_missing_model_uses_normal_entry(self):
        self.assertEqual(decide(Facts(model="")).action, "continue_install")

    def test_model_is_not_eligibility(self):
        baseline = decide(Facts(model="AM6B Plus"))
        for name in ("Box A", "Box B", "", "S905-series-user-device"):
            with self.subTest(name=name):
                self.assertEqual(decide(Facts(model=name)), baseline)

    def test_soc_does_not_change_policy(self):
        self.assertEqual(decide(Facts(soc="S922X")), decide(Facts(soc="unrecorded")))

    def test_recorded_testing_does_not_change_policy(self):
        self.assertEqual(decide(Facts(previously_tested=True)), decide(Facts(previously_tested=False)))

    def test_unknown_native_hash_is_not_a_warning(self):
        self.assertEqual(decide(Facts(native_sha256="a" * 64)), decide(Facts(native_sha256="b" * 64)))
        self.assertEqual(decide(Facts(native_sha256="")).device_notices, ())

    def test_version_alone_does_not_reject_usable_api(self):
        self.assertEqual(decide(Facts(kodi_version="21.3")), decide(Facts(kodi_version="22.x")))

    def test_no_private_methods_keeps_all_three_targets(self):
        self.assertEqual(dict(decide(Facts()).adapter_plan),
                         dict(playback="standard", subtitles="standard", continuation="standard"))

    def test_valid_native_operations_are_reused(self):
        result = decide(Facts(native_protocol_validated=True,
                              native_operations=frozenset({"playback", "subtitles", "continuation"})))
        self.assertEqual(set(dict(result.adapter_plan).values()), {"native"})
        self.assertEqual(result.action, "continue_install")

    def test_native_method_names_without_handshake_do_not_fake_protocol(self):
        result = decide(Facts(native_operations=frozenset({"playback", "subtitles", "continuation"})))
        self.assertEqual(set(dict(result.adapter_plan).values()), {"standard"})

    def test_partial_native_capability_falls_back_per_feature(self):
        result = decide(Facts(native_protocol_validated=True, native_operations=frozenset({"playback"})))
        self.assertEqual(dict(result.adapter_plan),
                         dict(playback="native", subtitles="standard", continuation="standard"))
        self.assertFalse(result.device_confirmation_required)

    def test_native_diagnostics_do_not_override_handshake(self):
        a = Facts(native_protocol_validated=True, native_operations=frozenset({"playback"}),
                  native_sha256="known-f9", model="AM6B Plus", previously_tested=True)
        b = replace(a, native_sha256="another-compatible-build", model="Other", previously_tested=False)
        self.assertEqual(decide(a), decide(b))

    def test_installable_dependencies_are_automatic_not_manual_gate(self):
        result = decide(Facts(dependency_state="automatically_resolvable"))
        self.assertEqual(result.action, "resolve_dependencies")
        self.assertIn("continue_setup", result.next_actions)
        self.assertEqual(result.problem, "")

    def test_real_dependency_failure_is_specific(self):
        result = decide(Facts(dependency_state="failed"))
        self.assertEqual(result.problem, "DEPENDENCY_INSTALL_FAILED")
        self.assertEqual(result.device_notices, ())

    def test_bad_package_still_rejected(self):
        self.assertEqual(decide(Facts(package_verified=False)).problem, "PACKAGE_INTEGRITY_FAILED")

    def test_unwritable_profile_is_real_error(self):
        self.assertEqual(decide(Facts(profile_writable=False)).problem, "PROFILE_NOT_WRITABLE")

    def test_insufficient_space_is_real_error(self):
        self.assertEqual(decide(Facts(enough_space=False)).problem, "INSUFFICIENT_SPACE")

    def test_actual_unadapted_required_api_failure_is_specific(self):
        result = decide(Facts(standard_api_usable=False))
        self.assertEqual(result.problem, "REQUIRED_API_UNAVAILABLE_AFTER_ADAPTATION")

    def test_abi_inventory_is_not_a_model_certification_gate(self):
        a = Facts(userspace_abi="arm", kernel_arch="aarch64")
        b = Facts(userspace_abi="aarch64", kernel_arch="aarch64")
        # Binary selection is elsewhere and still must load the correct ABI.
        self.assertEqual(decide(a), decide(b))

    def test_non_ce_is_a_scope_error_not_unknown_model(self):
        self.assertEqual(decide(Facts(coreelec=False)).problem, "NOT_A_CORELEC_INSTALL_TARGET")

    def test_bad_probe_types_do_not_become_true(self):
        with self.assertRaises(TypeError):
            decide(Facts(package_verified="yes"))

    def test_no_force_install_flag_or_risk_confirmation_contract(self):
        self.assertNotIn("force_install", Facts.__dataclass_fields__)
        self.assertNotIn("accept_risk", Facts.__dataclass_fields__)
        for tested in (False, True):
            r = decide(Facts(previously_tested=tested))
            self.assertFalse(r.device_confirmation_required)
            self.assertEqual(r.device_notices, ())

    def test_invalid_dependency_state_rejected_as_input_error(self):
        with self.assertRaises(ValueError):
            decide(Facts(dependency_state="pretend_ready"))

    def test_policy_has_no_device_side_effects(self):
        import ast
        from pathlib import Path
        source = Path(__file__).resolve().parents[1] / "reference" / "policy_contract.py"
        tree = ast.parse(source.read_text(encoding="utf-8"))
        roots = {n.module.split('.')[0] for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)}
        roots |= {a.name.split('.')[0] for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names}
        self.assertTrue(roots <= {"dataclasses", "typing"})
