# Bobbi TV PR 2 审查与 Codex 执行包

固定审查：CE2011，PR head 28819d202b6d4b4ff00367e46c37d8542a1b35af；合并 main ee65742bfcbaf08831f70306faed11bd1f8d6cc6。

结论：**2 项 P1、4 项 P2；先修安装与恢复问题，再交付下一安装候选。** 保留通用 CE、不设未知设备安装门槛及既有音视频策略。

## 给使用者

- REVIEW.zh-CN.md：完整审查、影响、源码链接、证据与后续路线。
- CODEX-EXECUTION.zh-CN.md：直接交给 Codex 的执行指令。
- FINDINGS.json / ACCEPTANCE.json：问题与验收的机器可读版本。
- run_review.py / checks/：读取指定候选仓库真实代码的行为门禁。
- SOURCE-PROVENANCE.json：固定提交、代码树与关键模块的 Git blob 校验值。
- evidence/：新增反例、89 项既有测试、15 项旧断言、两套原始 CI JUnit ZIP 及核查记录。

## 运行

在开发机 Python 3.11 或更新环境安装目标仓库 requirements-test.txt 中的依赖。不要将测试依赖安装到 Kodi 设备。

    python -m pip install -r /path/to/bobbi-tv/requirements-test.txt
    python run_review.py --repo /path/to/bobbi-tv --output result-current

Windows 示例：

    python -m pip install -r D:\BobbiTV\bobbi-tv\requirements-test.txt
    python run_review.py --repo D:\BobbiTV\bobbi-tv --output result-current

output 必须是新目录，避免覆盖先前证据。安装探针会启动两个短暂的本机回环 Runtime 子进程，测试 OS 实例锁与异常退出；需要允许本机回环 socket。它不连接用户 Kodi，不修改被测源码、账号或设备文件。

当前审查提交应得到：**18 项，10 通过、8 失败、0 errors，退出码 1。** 失败是正确行为断言暴露的缺陷，不是运行器崩溃；完整原始输出在 evidence/current-head-replay/。

修复候选目标是 18 项全部通过，同时保持原测试和正控。运行器记录候选的 Git 状态及实际文件哈希；修复后源码哈希改变是预期情况，不应为了保留旧哈希阻止测试。不要修改反例期望值、删测试或把环境错误记成产品通过。

此包是审查和整改任务材料，**不含已修复产品或可安装 ZIP**。产品整改与实机验证仍待执行。
