# Bobbi TV PR 2 独立审查报告

审查日期：2026 年 10 月 20 日。对象：[PR #2](https://github.com/2223M1/bobbi-tv/pull/2)，CE2011。结论依据为固定提交的源码、实际执行的反例、GitHub 原始 CI 回执及仓库中的设备记录。

## 审查结论

**保留 PR #2 的通用 CE 方向，在当前 main 上追加修复。CE2011 尚不能视为已经完成普通用户安装与恢复的闭环；建议先解决 2 项 P1，再交给朋友作为新的安装候选。**

本轮确认 **6 项问题：2 项 P1、4 项 P2**。其中 R01 是本 PR 引入的启动回归；R04 是本次 EOF 补查与继承字幕查询组合后的缺口；其余是本版仍存在的继承问题。它们不等于“本 PR 没有修好任何东西”。

独立新增的行为验证共 **18 项：10 通过、8 失败、0 errors**。8 个失败对应 6 项问题：R01 有两种启动顺序，R06 有观察与停止两种失败回执。测试直接加载目标仓库的实际 Python 模块，不内嵌另写的产品实现。

既有相关测试 **89 / 89 通过**；上一轮 15 项行为断言路由到本版实际模块后 **15 / 15 通过**。两套 GitHub CI 也确实各有 **2629 passed / 5 skipped**。问题在于这些既有测试没有覆盖本轮复现的跨模块边界，不能用总通过数替代相应行为证据。

## 1 固定审查对象

| 对象 | 精确值 |
| --- | --- |
| 仓库 | 2223M1/bobbi-tv |
| PR 状态 | 已合并 |
| Base | 1d421b101bdc3b940bdd5870caaac49a5fc49394 |
| PR head | 28819d202b6d4b4ff00367e46c37d8542a1b35af |
| 合并 main | ee65742bfcbaf08831f70306faed11bd1f8d6cc6 |
| 候选及合并代码树 | 8444201262d9ab298c901a0ed6f599b9b13735eb |
| PR CI 实际临时合并提交 | cae30462809a3b2b94436517f59563b9d536b02b |

GitHub 的 PR 元数据、实际 checkout 日志与 JUnit 回执相互吻合。[PR 交付说明](https://github.com/2223M1/bobbi-tv/pull/2#issuecomment-6291147094)、[候选 CI](https://github.com/2223M1/bobbi-tv/actions/runs/39424184404)、[PR 集成 CI](https://github.com/2223M1/bobbi-tv/actions/runs/39424192369)。

审查重点是本次四个产品逻辑文件，并沿调用链检查服务入口、运行实例、字幕与下一集解析、安装 bootstrap、构建及验收工具。源码通过 GitHub 插件按固定 head 获取，落地前逐文件校验 Git blob SHA。未将当前环境中的源文件快照冒充完整 Git 克隆；本轮未本地重跑全套 CI 或完整安装产物构建。详细来源与校验值见 SOURCE-PROVENANCE.json。

## 2 用户约束与这版应保留的实现

继续做通用 CoreELEC 版本。AM6B Plus 是现有实测基底；未知设备可以进入朋友内测。**本次建议不增加型号白名单、未知设备风险确认、F9 安装硬门槛或第二台设备准入要求。** 这与本版发布配置一致。[ce-general-2011.json](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/release/ce-general-2011.json)

保持手动选源、准确同版续播、原始音视频质量及语言、手动字幕 Off、账号代际隔离、账号与观看数据保护。继续使用当前 addons/ 作为本仓库源码，不把前身仓库 ui-redesign/ 的旧路径机械套到新仓库。安装入口的 bootstrap 继续来自同一个签名载荷，不维护第二份逻辑。

已检查到的实质改进：

- A02：成功识别明确无关的视频后，会撤销旧续播会话、取消 worker 并清掉后继候选。空路径或暂态读取失败仍不会直接当作外部接管。
- A03：后继提交边界捕获异常，区分提交前失败与提交结果未知；结果未知不会盲目重发，单次后继失败不再直接退出驻留宿主。
- A04：同版下一集发现有单 worker、退避、次数上限和 EOF 后补查；绝对有效期不再被候选或外部播放无限延长。
- A01：文件可运行状态与宿主待完成操作分离，加入待激活、待恢复与读回确认；兼容旧 CE2009 的 restored + host_pending 语义有实际价值。但它遗漏了真正服务入口及运行实例的恢复边界。

依据：[standard_session.py](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/standard_session.py)、[standard_playback.py](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/plugin.video.bobbi/lib/services/standard_playback.py)、[ce_installer.py](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/ce_installer.py)。

## 3 问题总表

| 编号 | 优先级 | 问题 | 与本 PR 的关系 | 下一步 |
| --- | --- | --- | --- | --- |
| R01 | P1 | 待激活状态被真正的服务入口拒绝，启用标志仍可让安装被记为完成 | 本 PR 新引入 | 统一入口语义，补运行就绪与重入恢复 |
| R02 | P1 | 未完成事务中，死进程留下 runtime.json，恢复反复超时 | 继承问题，本轮 A01 未覆盖 | 用真实实例所有权识别和处理陈旧登记 |
| R03 | P2 | RPC 读取未知被当成 disabled，保存错误的回退启用向量 | 继承问题 | 严格读取关键事务快照 |
| R04 | P2 | 下一集媒体已找到，可选字幕查询却耗尽 EOF 有效期 | 新旧逻辑组合缺口 | 将可选字幕等待限制在剩余预算内 |
| R05 | P2 | 无效进度样本刷新了旧片尾位置的有效时间 | 继承问题，base/head 均复现 | 分开关联观察与有效进度时间 |
| R06 | P2 | 实机工具明确返回失败，进程却仍退出 0 | 继承问题，base/head 均复现 | 按各操作业务结果产生正确退出码 |

P1 在这里表示应先于新安装候选分发处理的启动/恢复缺陷，不表示每次安装都必现，也不表示固件或用户数据已经受损。

## 4 R01 待激活状态与真正服务入口冲突

### 实际代码

安装器的 RUNNABLE 允许 activation_pending；真正的影院入口 lib/boot_gate.py 却只接受 complete、restored。service.py 在调用任何驻留宿主前执行后者，不通过就 SystemExit(0)。

| journal 状态 | 安装器认为可运行 | 真正服务入口允许 |
| --- | --- | --- |
| staged / switching / restoring | 否 | 否 |
| activation_pending | 是 | **否** |
| restored + host_pending=restore | 是 | 是 |
| complete / restored 无 pending | 是 | 是 |

同时，KodiHost.activate() 跳过已经 enabled 的组件；Installer._activate() 检查的只是启用向量，随后便写 complete。[ce_installer.py:111–140](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/ce_installer.py#L111-L140)、[ce_install_ui.py:110–114](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/ce_install_ui.py#L110-L114)、[boot_gate.py:6–17](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/plugin.video.bobbi/lib/boot_gate.py#L6-L17)、[service.py](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/plugin.video.bobbi/service.py)。

### 两个已执行反例

第一种是合法调度下的安装竞态：启用 provider 触发真实 service.py，服务先看到 activation_pending 而退出；安装器后续仍读到 enabled=true，写 complete。结果为 enable_provider → service_exit:0，phase=complete，重开 recover=false，宿主没有运行。

第二种更明确：**启用标志已经落地，但 journal 尚未完成时进程丢失。**

1. Kodi 重启，尝试启动已启用服务。
2. 服务看到 activation_pending，立即退出。
3. 用户重开“波比开始使用”。
4. recover() 发现 provider 早已 enabled，跳过重新启用。
5. journal 变 complete，服务仍未启动。

反例结果是 reboot_service_exit:0、reopening_recovered=true、phase=complete，但没有 host_started。

Kodi 官方实现中，启用事件通过队列发送，服务管理器处理事件并异步启动脚本。启用标志不是脚本已经运行的回执。[Kodi Service.cpp](https://github.com/xbmc/xbmc/blob/21.3-Omega/xbmc/addons/Service.cpp#L36-L96)、[EventStream.h](https://github.com/xbmc/xbmc/blob/21.3-Omega/xbmc/utils/EventStream.h#L65-L81)。正常安装的竞态不能写成“每次必坏”；启用后丢进程再重启的路径则说明 advertised recovery 确有缺口。

### 为什么既有测试没抓住

tests/ce_install_faults.py 使用的是 ce_installer.blocked()，没有让真正的 service.py 走 lib.boot_gate.ready()。它验证了安装器自己的判断，漏掉了两个判断互相矛盾。[故障替身](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/tests/ce_install_faults.py#L33-L48)

构建也没有替源码修正门禁：source-inventory 固定该文件，build_release 按原字节写 ZIP；build_ce_entry 提取同代 platform bootstrap，不重写 plugin 的 gate。[构建逻辑](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/tools/build_release.py#L58-L65)、[入口构建](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/tools/build_ce_entry.py#L29-L49)。

### 修复要求

让独立的真实启动门禁理解已核验的待激活状态，并保持导入可替换依赖前的保护。补“已 enabled 但未运行”的恢复与就绪确认；仅再读 enabled 不够。**不要恢复为“先写 complete 再启用”来消掉测试。**

同时保留 staged/switching/restoring 禁启动、旧 restored + host_pending 回退兼容、代次高水位。测试必须执行实际 service.py，覆盖启用事件、进程丢失、重启及重开入口的顺序。

对应执行包用例：INSTALL-BOOT-GATE、INSTALL-BOOT-AFTER-ENABLED-PROCESS-LOSS。

## 5 R02 陈旧运行登记使未完成事务无法恢复

KodiHost.quiesce() 只等 runtime.json 消失，15 秒后报 CINEMA_SERVICE_NOT_STOPPED。真实 Runtime 正常 close 时会删它；异常退出无法执行 close。运行文件存在并不等于进程还活着。[quiesce](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/ce_install_ui.py#L74-L90)、[Runtime](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/runtime.py#L118-L157)

本轮启动真实 Runtime 子进程，待其写入登记后 os._exit(73)。父进程成功重新独占取得原实例锁，证明旧宿主已经消失；runtime.json 仍在。随后在 staged journal 上执行真实 Installer.recover → KodiHost.quiesce，两次均报同一超时，journal 仍停在 staged。只加速 15 秒等待时钟，没有改写 quiesce。

阻断发生在**安装/回退处于会阻止新服务启动的中间阶段**：旧服务不能清理、新服务被 gate 拦住、恢复入口又等待旧文件自行消失。不是所有普通崩溃都会进入这个状态；complete 且正常重启服务时，Runtime.start 可以覆盖旧登记。

修复应利用既有 OS 实例锁等实际所有权，确认原宿主已退出、组件已停用，并在防止新实例抢入的范围内处理陈旧登记。保留锁文件身份，不能用删锁文件、猜 PID、放宽超时或“HTTP 没响应就删文件”代替正确的排他控制。对应 [instance_lock.py](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/instance_lock.py)。

正控已经验证：真实存活 Runtime 仍持锁时，不能删登记，也不能开始换代。修复后还应覆盖 staged、switching、restoring 三种状态，并保持账号与观看数据不变。

对应用例：INSTALL-STALE-RUNTIME、CONTROL-ACTIVE-RUNTIME-OWNER。

## 6 R03 未知启用状态被保存成关闭状态

KodiHost.details() 将任意 RuntimeError 变成 None；enabled() 随后把它当作“未启用”。安装前恰好使用该函数保存回退向量。一次暂态 RPC 读取失败，就可能把原本启用的 provider 从向量中漏掉。[读取](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/ce_install_ui.py#L26-L34)、[快照持久化](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/ce_installer.py#L174-L183)

本轮只在保存快照时让一次 GetAddonDetails(plugin.video.bobbi) 抛错，后续 RPC 全部正常；执行真实 old/new 目录移动、激活及回退。结果：

- originally_enabled_provider=true；
- saved_enabled_provider=false；
- final_enabled_provider=false；
- all_old_files_restored=true；
- phase=restored。

文件都回来了，但原本应运行的宿主被错误关闭，回退还被记为成功。后续读回只能证明“错误快照已经正确应用”，无法纠正快照本身。[restore](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/ce_install_ui.py#L116-L125)

关键事务读取必须区分明确存在及状态、明确不存在、读取未知。未知时在程序切换前停止或有界重试，不得静默记 false。普通可选能力探测可以维持容错，不必全项目把所有读取失败都升级为致命错误。

对应用例：INSTALL-ENABLE-SNAPSHOT-UNKNOWN。

## 7 R04 慢字幕查询吞掉已就绪下一集

next_with_subtitle() 先取得准确下一集，再串行等最长 30 秒字幕查询。A04 新增的 EOF 后补查却只有 20 秒绝对有效期。媒体即使一开始已可播，也要等字幕查询结束才返回；超过有效期时，guard 把整个媒体结果一起丢掉。[串行字幕等待](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/plugin.video.bobbi/lib/services/standard_playback.py#L164-L174)、[EOF 截止与最终补查](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/standard_session.py#L160-L183)

反例经过真实 StandardSession worker 与 next_with_subtitle：EOF 后立即得到准确下一集，字幕 IO 迟缓且无结果；最终 state=retired，自动后继 0 次。不是因为下一集不存在，也不是因为用户换片。原始观察探针用超过 20 秒的等待；候选门禁使用尊重传入 deadline 的确定性替身，允许修复合理缩短可选 IO 预算。

修复可将字幕等待限制在剩余预算内，或分别发布媒体与可选字幕结果。保留绝对 20 秒、单个媒体发现 worker、同版策略及用户意图取消；不靠无限延长窗口、关闭续播、关闭字幕、换低画质源解决。迟到字幕继续走显式选择，不自动覆盖手动 Off。

对应用例：test_ready_next_media_is_not_discarded_by_optional_subtitle_delay。正控要求真实可用候选恰好续播一次，确实无候选时不伪造。

## 8 R05 无效进度把过期片尾证据变新

observe() 先更新 observed，再校验 position/duration。收到 0/0 这类不可用进度时，旧 position/duration 保留，observed 却刷新。terminal() 用这个新时间判断是否“最近 3 秒看到了片尾”。[observe](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/standard_session.py#L79-L96)、[terminal](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/addons/script.module.bobbi.platform/lib/bobbi_platform/standard_session.py#L124-L134)

已在 base 与 head 执行：t=100 收到有效 99/100；40 秒后收到同一文件的 0/0；接着 ENDED。当前代码仍判 NATURAL_EOF，写 completed=true，并在 0.3 秒后续播一次。旧的有效片尾样本实际已过去 40 秒。

将“观察到这个文件仍属于会话”与“观察到有效进度”的时间分开。只有数值和范围有效的进度才能更新 EOF 判断使用的时间。保留暂态读取失败时的会话关联，不得为了避免误判直接取消整个会话。新鲜有效片尾证据仍必须正常完成和续播。

对应用例：test_invalid_progress_sample_cannot_refresh_eof_evidence。

## 9 R06 失败回执仍返回成功退出码

result_exit_code() 检查远程异常、sample.failure、选源和启动 trace，却没有检查观察的 passed 或停止的 stopped。[本地验收出口](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/tools/ce_playback_trial.py#L12-L25)

远端实际逻辑能够产生：

| 操作 | 业务结果 | 当前退出码 |
| --- | --- | --- |
| observe 观察到 caching 或时间推进不合格 | passed=false | 0 |
| stop 等待 12 秒仍存在活动播放器 | stopped=false | 0 |

这不是只给函数捏造一种实际不存在的数据形状。执行包保留原始成功设备回执作正控；失败输入是明确标注的副本，按 ce_trial_remote 的现行条件设置 caching、passed 或 stopped。[远端输出逻辑](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/tools/ce_trial_remote.py#L632-L666)

head 与 base 的函数内容相同，两种失败都复现，原始成功回执仍通过。本问题会使依赖退出码的自动执行把明确失败算成成功；**不意味着仓库这次公布的所有实机失败已经被偷偷改成通过**，原交付文档确实保留了这些开放项。

按每种操作定义业务成功条件，明确 false 必须非零；保留 cards/inspect 等读取命令与 not_tested 的区别。落盘时建议分开 transport_exit_code 与 trial_exit_code，先算业务结果再保存，避免把远程 Python 返回 0 当成验收成功。原播放判据和阈值保持不变。

对应用例：observe_failed_caching_sample、stop_wait_timed_out。

## 10 测试与交付证据应怎样解读

| 验证 | 本轮核查结果 | 可支持的结论 |
| --- | --- | --- |
| 候选 push CI | 原日志及 JUnit，2629 过 / 5 跳过 | 固定候选通过当前仓库测试及 source-check |
| PR 集成 CI | 原日志及 JUnit，同样 2629 / 5 | 实际集成树也通过，且与 main 同树 |
| 最终 main CI | workflow API success | main 对应工作流成功；不重复累计测试数量 |
| 既有相关测试 | 本轮本地 89 / 89 | 安装恢复及标准播放既有回归通过 |
| 上一轮行为断言 | 本轮本地 15 / 15 | 上轮冻结断言在当前实际模块上通过 |
| 本轮新增契约 | 本轮本地 18 项，10 过 / 8 败 / 0 errors | 本报告 6 项缺陷可重放 |
| 入口及载荷 | GitHub 资产大小、digest 与清单一致 | 上传对象元数据匹配；本轮未重新下载约 96MB 包验签 |
| 设备 | 读取已有回执及生成工具 | 本轮没有新的电视或普通 CE 实机操作 |

CI 每套：primary 1695 passed / 5 skipped，baseline 757 passed，preparation 177 passed。五个跳过均属于 Linux 上不适用的 Windows inherited-pipe 测试，不是隐藏的 Linux 符号链接失败。本轮本地 Python 为 3.12；CI 为 3.11；这是开发机测试环境，不改变 Kodi 的产品运行要求。[CI 配置](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/.github/workflows/verify.yml)

### 当前作品结果

**《十二怒汉》：** 已有记录证明分享读取在 grant 阶段 unexpected_exception，交付 0 字节，本地流服务返回 503。下轮先定位授权取址异常类别和上游响应。现有证据不能断定只是外部坏源，也不能归因解码器崩溃。[原日志](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/review-evidence/ce-playback-log-1792499389806416100.json)

**《四叠半神话大系》：** 起播记录仍未通过。2.4938 秒异常期间，媒体时钟停在 5.006，解码帧数从 137 增至 195，caching=false；随后时钟跳到 8.009。因此应称“起播计时异常，呈现连续性未证实”，不能直接写“画面实测卡死 2.5 秒”，也不能反过来宣布已经无卡顿。[首播记录](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/review-evidence/ce-new-work-tatami_galaxy-select-1792499924442345600.json)

后段 30.312 秒内媒体推进 30.322 秒是真实的通过记录，但只有约每 10 秒一次的四个采样点；它不抵销起播异常，也不解决中文字幕缺失。[后段记录](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/review-evidence/ce-new-work-tatami_galaxy-observe-1792499985968581700.json)

此前《这个男人来自地球》的起播缓冲、《玲音》的缓冲与中文字幕缺失继续开放。不要用另一作品成功、后段通过或降低阈值替换原失败。[CE2011 记录](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/docs/CE-GENERAL-2011-20261020.md)

### 普通 CE 完整链还缺哪一段

现有标准适配器短片测试真实跑了两次 AV、两次 EOF 和交付，但将 next_loader 替成固定返回第二段本地短片的函数。它未验证真实同版发现、分享取址与可选字幕这一段。[fixture](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/tools/ce_standard_fixture_remote.py#L35-L46)

真实作品工具仍使用 Player.BobiState 等原生接口及 Amlogic 观察节点。因此，应在已有盒子上增加一条确实经过标准适配器、真实 next_loader、真实来源与自然 EOF 的端到端验证；没有第二台硬件不妨碍开展它，更不应变成未知设备安装限制。[真实作品工具](https://github.com/2223M1/bobbi-tv/blob/28819d202b6d4b4ff00367e46c37d8542a1b35af/tools/ce_trial_remote.py#L65-L78)

## 11 建议的下一轮顺序

第一阶段一起修 R01、R02、R03，并先运行本执行包中的对应反例。安装成功应证明真实宿主可用，恢复成功应证明文件和关键宿主状态恢复；不是只证明 journal 已到终态。

第二阶段修 R04、R05，保留本版 A02/A03 的外部接管、错误隔离与同版策略。补慢字幕、无字幕、无下一集、无效进度、手动停止和新选择的交叉场景。

第三阶段先修 R06，再使用修好的工具验证实际入口 ZIP 与真实标准播放链。否则后续自动化仍可能给出错误的成功信号。

最后在下一未占用代次构建新的签名载荷与入口，核对入口 bootstrap、嵌套 plugin 门禁与源码清单属于同一候选。保留 CE2009、CE2010、CE2011 的原包和原失败记录。使用当前允许的私有候选流程，不回滚通用化合并，不修改未知机型政策。

详细动作、命令、禁止取巧条件与交付要求见 CODEX-EXECUTION.zh-CN.md；机器可读的验收表见 ACCEPTANCE.json。
