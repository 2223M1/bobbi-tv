# Bobbi TV CE2011 后续 Codex 执行指令

你现在接手 2223M1/bobbi-tv PR #2 合并后的下一轮修复。请直接完成代码、回归、候选构建与可复核交付；不要只给计划或重复 PR 的文字结论。

## 目标与基线

PR：https://github.com/2223M1/bobbi-tv/pull/2

- 审查 base：1d421b101bdc3b940bdd5870caaac49a5fc49394。
- 审查 head：28819d202b6d4b4ff00367e46c37d8542a1b35af。
- 已合并 main：ee65742bfcbaf08831f70306faed11bd1f8d6cc6。
- 对应 tree：8444201262d9ab298c901a0ed6f599b9b13735eb。
- 当前入口 script.bobbi.start 0.2.3；platform 0.1.9；plugin 0.1.7；本轮审查版本为 CE2011。
- 审查确认 6 项：R01/R02 为 P1；R03/R04/R05/R06 为 P2。原始结果、来源与完整说明在同包 REVIEW.zh-CN.md、FINDINGS.json、ACCEPTANCE.json。

先读取当前仓库 AGENTS.md 和本执行包。检查 origin/main 是否已前移；如前移，核对这 6 项是否已有修复，从当前有效基线继续，不重置新提交。使用隔离分支/工作树，不覆盖已有 dirty 工作区。当前权威源码为本仓库 addons/，不是前身项目的 ui-redesign/。

保持通用 CE 产品方向。未知硬件直接允许内测；不加型号白名单、未知机型风险提示或额外确认，不恢复 F9 型号/哈希安装准入，不以第二台硬件认证为前提。AM6B Plus 是现有测试基底，不是产品唯一目标机。

保留准确同版选源、原始分辨率与码流、原语言、手动字幕 Off、账号代际、账号/观看库和无关插件。原生 F9 的协议、CD2 1.0.19、挂载、Yatse、VPS newapi/代理及固件不因本轮审查而更改。入口 bootstrap 继续来自同一签名载荷。修复范围限于以下明确缺陷与必要验证。

## 先保存已知失败对照

在开发机 Python 3.11+ 环境安装仓库 requirements-test.txt；这些依赖不是装到 Kodi 上。

    python -m pip install -r requirements-test.txt
    python /path/to/review-pack/run_review.py --repo /path/to/bobbi-tv --output /path/to/new-result-directory

审查固定 head 的预期原始结果：18 项，10 passed / 8 failed / 0 errors，进程退出 1。8 个失败对应 6 项问题，不能当成 8 个独立缺陷。

若当前 main 已修复一部分，记录实际差异和通过项，不为制造“先红”而回退用户代码。固定 baseline 只在独立工作树重放。运行器会加载传入仓库的真实模块，记录 commit/tree/文件哈希；不需要打包冻结产品源码。

原脚本、原断言、原失败记录保留。不要将期望改成错误行为、删反例、改成 xfail/skip，或用关闭功能取得通过。允许为真实接口重构调整 IO 替身接线，但必须说明保持了什么行为契约，并保留原对照。

安装探针只创建临时目录及本机回环 Runtime 子进程。若执行环境禁止本机 socket，应使用获准的本机测试环境；把环境失败单列，不能记成产品失败或通过。

## T01 修复 R01 真实启动门禁与待激活恢复

重点文件：

- addons/script.module.bobbi.platform/lib/bobbi_platform/ce_installer.py
- addons/script.module.bobbi.platform/lib/bobbi_platform/ce_install_ui.py
- addons/plugin.video.bobbi/lib/boot_gate.py
- addons/plugin.video.bobbi/service.py
- tests/ce_install_faults.py 及安装恢复测试

当前 activation_pending 被安装器判定为可运行，却被真实 service.py 的 boot_gate 拒绝。enabled 已落地、journal 未完成后重启，recover 会跳过已启用 provider，最终写 complete 而服务仍未运行。

要求：

1. 真实独立入口理解“文件已核验可运行但宿主激活未完成”。继续在导入可替换依赖前完成门禁判断。
2. 为 enabled=true 但宿主没有运行的情况提供明确的恢复/就绪确认。不要只确认 Addons.GetAddonDetails 的 enabled。
3. 保留 staged/switching/restoring 禁启动；保留 CE2009 restored + host_pending=restore 兼容、CE2010 中间 journal 兼容以及高水位。
4. 不恢复旧版“先写 complete 后启用”的伪完成逻辑；不靠固定 sleep 猜测服务已经起来。
5. 在真实 service.py 上测服务先于完成写入、启用后进程丢失、Kodi 重启后入口恢复。既有 fault host 只调用 ce_installer.blocked() 不足以覆盖这条链。
6. 核对最终入口 bootstrap 和签名载荷中实际 plugin boot_gate，避免只修开发源码或其中一份入口。

通过 INSTALL-BOOT-GATE、INSTALL-BOOT-AFTER-ENABLED-PROCESS-LOSS 以及 5 个门禁/静默 RPC 正控。

## T02 修复 R02 中间事务的陈旧 runtime 登记

重点文件：ce_install_ui.py 的 quiesce，runtime.py，instance_lock.py，以及恢复入口。

Runtime 异常退出后 OS 实例锁已释放，但 runtime.json 仍在。staged/restoring 等状态又阻止新 Runtime 启动；恢复入口只等旧登记消失，每次报 CINEMA_SERVICE_NOT_STOPPED。

要求：

1. 依据既有 OS 实例锁或等效真实所有权确认旧宿主是否已退出。
2. 处理残留登记前确认其属于已退出实例，并防止新实例在检查与删除间抢入。保留稳定的锁文件身份；不要删除锁文件以绕过排他。
3. 活实例仍持锁时继续拒绝换代，即使某个 RPC 已显示 disabled 或网络探测失败。
4. 确认退出边界覆盖换代真正依赖的工作。不能把 HTTP 超时、PID 猜测或文件存在与否当作唯一依据。
5. 覆盖 staged、switching、restoring 中真实子进程强制退出及入口重开；账号、观看库、无关插件不回滚。
6. 普通 complete 状态崩溃可以自愈，不要为了本缺陷把所有启动都变成破坏性重置。

通过 INSTALL-STALE-RUNTIME，保留 CONTROL-ACTIVE-RUNTIME-OWNER。

## T03 修复 R03 关键事务快照的未知状态

KodiHost.details() 当前把 RuntimeError 返回为 None，enabled() 把它当成 disabled。一条 RPC 暂态失败即可保存错误回退向量，之后恢复能“成功”关闭原本启用的 provider。

要求：

1. 给关键事务读取区分明确不存在、明确启用/禁用、未知/读取失败。
2. 快照不完整时在程序文件切换前停止或有界重试，保留可重试入口；不得保存一个看似完整的缺项向量。
3. 用严格读取确认恢复和激活，不把未知当 false。
4. 保留可选依赖/能力探测的适度容错；不要无必要全局改为致命错误。
5. 测保存快照时一次和多次 GetAddonDetails 失败；测原本开启和关闭的各组件及皮肤确实恢复。单纯“恢复结果等于错误快照”不是通过。

通过 INSTALL-ENABLE-SNAPSHOT-UNKNOWN。

## T04 修复 R04 可选字幕阻塞已就绪后继媒体

重点：standard_playback.py 的 next_with_subtitle、standard_session.py 的最终补查/截止预算。

EOF 后最终补查只有 20 秒，但媒体就绪后仍可能串行等 30 秒字幕；最后 guard 丢弃可播放媒体。

要求：

1. 下一集媒体与可选字幕不相互绑死。可分开发布结果，或把字幕等待限定在剩余有效期内且留出提交时间。
2. 不延长 EOF 绝对 20 秒、不扩大同版匹配、不新增云任务、不自动换源降画质。
3. 媒体发现保持最多一个 worker、既有退避与次数上限；不要用更多后台线程掩盖阻塞。
4. 迟到字幕保持显式选择，不自动覆盖用户 Off；正常及时字幕仍可用。
5. 覆盖 EOF 才找到媒体、字幕慢且无结果、字幕及时、没有媒体候选、用户外部改播/手动停止/换账号后取消。
6. 真实可用准确候选仍须只续播一次，确实没候选不能造一个结果。

通过 test_ready_next_media_is_not_discarded_by_optional_subtitle_delay 及两个候选正负对照。

## T05 修复 R05 进度证据时间

重点：standard_session.py 的 observe 与 terminal。

当前 99/100 的有效片尾样本已过去 40 秒，再收到 0/0，observed 却变新，ENDED 仍会完成/续播。

要求：

1. 分开“关联观察时间”和“有效进度样本时间”。
2. 有效数值及范围通过后才能刷新 EOF 证据；无效样本不使旧位置续命。
3. 暂态空值/seek 期间保留可恢复会话，不直接判外部接管或取消。
4. 新鲜有效 EOF 保持完成且准确下一集仅一次；STOPPED/ERROR 不误完成。

通过 test_invalid_progress_sample_cannot_refresh_eof_evidence，保留 test_fresh_valid_eof_continues_exact_candidate_once。

## T06 修复 R06 业务失败退出码和证据字段

重点：tools/ce_playback_trial.py 的 result_exit_code 与 main，tests/test_ce_trial_control_boundaries.py。

observe 的 passed=false、stop 的 stopped=false 目前仍可 exit 0；落盘 exit_code 又只记录远程进程结果。

要求：

1. 按 operation 定义成功形状：observe、stop、cancel、select 等不能只依赖传输无异常；明确业务 false 必须非零。
2. cards/inspect 等正常读取不强行套用播放通过字段；not_tested 继续区分；缺失必须字段不能默认为成功。
3. 在写证据前计算业务结果；分别保存 transport_exit_code、trial_exit_code 或等义清晰字段，并使命令退出与业务结果一致。
4. 保留原始成功回执及明确构造的失败变体；不修改播放质量判据或阈值。
5. 所有后续实机命令都使用修正后的业务判定。

通过 run_trial_gate.py 四项；同时保留既有控制工具回归。

## 必须执行的验证

先跑本执行包，目标 18 项全部通过、0 errors。用新的 output 目录保存每轮结果。

然后按仓库现行 CI 分进程执行：

    python -m pytest -q -rs tests --ignore=tests/private_baseline --ignore=tests/preparation_regression --junitxml=review-evidence/remediation-primary.xml
    python -m pytest -q -rs tests/private_baseline --junitxml=review-evidence/remediation-baseline.xml
    python -m pytest -q -rs tests/preparation_regression --junitxml=review-evidence/remediation-preparation.xml

保留冻结文件与期望，运行：

    python tools/replay_ce2009_candidate.py --output review-evidence/remediation-previous-assertions

变更源码、组件版本后，逐项审查 inventory 差异再刷新并构建，不以刷新清单消除未理解的异常：

    python tools/build_release.py --refresh-inventory --source-check --output dist/remediation-source-a
    python tools/build_release.py --source-check --output dist/remediation-source-b
    python tools/check_repository.py dist/remediation-source-a dist/remediation-source-b

原 CI 的 2629 passed / 5 skipped 是基线数量；修复后报告实际通过/跳过，解释差异，不为对齐数字删除新测试。记录候选 head、PR 实际集成 commit 和 tree，确认验证的树就是交付的树。source-check 仍不等于可安装签名包。

## 真实候选和设备验证

使用已有维护者应用配置和可信签名流程，选下一未占用代次；若 CE2012/2026102012 已占用，继续后继，不覆盖 CE2011 或旧包。更新实际改动组件版本、嵌套载荷与入口，bootstrap 仍从同一个已签名 platform 提取。不得生成新信任根替换既有签名密钥。

实际构建/签名工具的已知参数为：

    python tools/build_release.py --output dist/remediation-private-components
    python tools/sign_private_bundle.py --key <既有私钥路径> --components dist/remediation-private-components --profile coreelec --sequence <下一未占用代次> --output <新的完整载荷.zip>
    python tools/build_ce_entry.py --bundle <新的完整载荷.zip> --output <新的入口.zip>
    python tools/audit_ce_entry.py <新的入口.zip> --report review-evidence/remediation-entry-audit.json

尖括号是需要从本地现有配置解析的参数，不要直接原样执行，也不要把密钥内容输出到聊天/日志。维护者配置缺失时，完成源代码、测试、source-check 和可审查 PR，再准确报告签名产物缺口；不能将 source-check 伪装成最终包。

在当前已有授权的测试条件下继续设备验证：

- 完整用户入口 ZIP：分别验证新装、从 CE2009/CE2011 更新、启用中断后重开、回退。以实际服务运行及可用性验证成功，不只读 addon enabled。
- 干净安装使用隔离测试配置或可还原的测试副本，不清空现有账号与观看库；没有合适环境时，如实保留未实测项。
- 用户 ZIP 的操作路径与维护部署路径分别留回执；SSH 精确维护部署不能代替普通用户安装验收。
- 普通 CE 标准链：在已有盒子上增加显式、可恢复的标准适配器测试入口，确认实际经过 StandardPlayback、真实 next_loader、真实分享取址和自然 EOF。现有固定第二片 lambda fixture 只保留作协议对照。
- 原作品回归：先查《十二怒汉》grant / unexpected_exception / 0字节 / 503；《四叠半》分开记录起播计时、解码计数及呈现连续性。原《这个男人来自地球》和《玲音》问题继续挂账。
- 不把缺第二台 CE 硬件变成安装门槛。其他设备结果按实测范围记录，不虚构认证。

《四叠半》首播“2.4938 秒”不能直接等同于画面冻结；期间解码帧数有推进，呈现连续性还需证据。也不能据此删掉原失败或提高阈值。后段 30 秒正常不能抵销首播与中文字幕缺失。

维护部署若要回退，先读取对应 frozen run 与当前代次。旧 20261020-203300 只对应 CE2011→CE2010；20261020-203000 对应 CE2010→CE2009。新修复代次必须建立新的独立备份/run，不能跨代调用旧 run，也不整库覆盖 userdata。

## 最终交付

交付一份可审查的修复 PR、完整回执及下一候选。保持私有发布与现有草稿流程。

每项 R01–R06 单独列出：改动文件/提交、修复后的行为、对应反例结果、现有回归、实机结果或尚未验证项。建议安装事务、标准续播、验收工具各成清晰提交，避免混入 Android、大规模 UI、引擎或产品方向重构。

最终说明必须同时回答：

1. 本包 18 个行为契约是否全部通过；原 15 个断言是否仍通过？
2. 完整三套回归和实际 head/集成树 CI 各是什么结果？
3. 安装完成是否证实宿主可运行；进程丢失后是否能恢复？
4. 签名载荷、入口、bootstrap、嵌套 plugin 门禁与 source inventory 是否属于同一代次？
5. 哪些是真实用户 ZIP 操作，哪些是维护部署或 IO 替身？
6. 普通标准路径是否真正跑过完整真实剧集后继；哪些作品失败仍开放？
7. 最终入口/载荷的名称、字节数、SHA256、恢复方法与当前设备状态是什么？

不要只回报“测试全绿”或“已经部署”。把结果和未闭环范围写清楚。
