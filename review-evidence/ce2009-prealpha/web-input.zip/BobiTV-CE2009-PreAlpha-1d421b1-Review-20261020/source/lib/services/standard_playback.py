"""Resident standard-Kodi observation and shared cinema policy adapters."""
from copy import deepcopy
from queue import Queue, Empty, Full
from uuid import uuid4
from threading import Event, Thread
import time

from bobbi_platform.standard_session import StandardSession


class HistoryWriter:
    """Bounded single writer; a slow disk must not stall callbacks or IPC."""
    def __init__(self, report):
        self.queue, self.done, self.report = Queue(maxsize=32), Event(), report
        self.worker = Thread(target=self.run, name='bobbi-standard-history', daemon=True)
        self.worker.start()

    def save(self, data):
        try:
            self.queue.put_nowait(deepcopy(data))
        except Full:
            self.report('HISTORY_QUEUE_FULL')

    def run(self):
        while not self.done.is_set() or not self.queue.empty():
            try:
                data = self.queue.get(timeout=.1)
            except Empty:
                continue
            try:
                from lib.utils.general.utils import set_watched_file
                set_watched_file(data)
            except Exception:
                self.report('HISTORY_WRITE_FAILED')

    def close(self):
        self.done.set()
        self.worker.join(timeout=.3)


def discover(data, host, deadline, cancelled):
    from lib.services.subtitle_fallback import playback_context, discover_candidate
    from bobbi_core.subtitle_candidates import AssrtCandidates
    from bobbi_core.runtime_paths import ProfilePath
    provider = AssrtCandidates(None, ProfilePath('subtitle-cache283'), accounts=host.accounts)
    return discover_candidate(playback_context(data, None), deadline, cancelled,
                              provider, host.sidecar_candidate)


def resolve_selected(data, cancelled):
    """Reuse verified resolvers without depending on native player receipts."""
    if data.get('_catalog_next'):
        from lib.utils.player.direct_continuity import resolve_direct
        data['url'] = resolve_direct(data, cancelled)
    if data.get('direct_cloud_required') or data.get('direct_cloud_key'):
        from bobbi_core.direct_cloud_client import resolve
        resolved = resolve(data, cancelled)
        if not resolved:
            raise ValueError('SELECTED_CLOUD_FILE_UNAVAILABLE')
        data.update(url=resolved['path'], direct_cloud_key=resolved['key'], size=resolved['bytes'])
        data.pop('direct_cloud_required', None)
    if data.get('prepared_resource_id'):
        from lib.clients.bobi_library import load_prepared_index, local_path
        from bobbi_core.preparation_client import resolve_entry
        snapshot = load_prepared_index()
        entries = [entry for title in snapshot['titles'] for entry in title['sources']
                   if entry['key'] == data['prepared_resource_id']]
        if len(entries) != 1 or not resolve_entry(data, snapshot, entries[0], cancelled):
            raise ValueError('SELECTED_CLOUD_FILE_CHANGED')
        entry = entries[0]
        data.update(url=local_path(snapshot['mount_root'], entry['path']),
                    source_title=entry['title'], video_context=entry.get('video_context'),
                    subtitles_path=[local_path(snapshot['mount_root'], path)
                                    for path in entry.get('subtitles', [])[:4]])
    if cancelled():
        raise RuntimeError('SELECTION_CANCELLED')
    return data


def next_data(current, cancelled):
    if current.get('file_evidence') == 'USER_CONFIRMED_FILE':
        return None
    from lib.utils.player.direct_continuity import next_direct_data
    from lib.utils.player.continuity import next_cloud_data
    try:
        from lib.clients.bobi_library import load_prepared_index
        index = load_prepared_index()
    except (OSError, ValueError, RuntimeError):
        index = {'titles': []}
    data = next_cloud_data(current, index)
    if data is None:
        data, _ = next_direct_data(current, index, cancelled)
    if not data or cancelled():
        return None
    data.update(request_id=uuid4().hex, selection_policy='exact',
                _account=deepcopy(current['_account']), direct_playback_handoff=True)
    return resolve_selected(data, cancelled)


class StandardPlayback:
    def __init__(self, host):
        import xbmc
        self.host = host
        self.events = Queue(maxsize=64)
        self.bound = ''
        self.subtitle_worker = self.subtitle_job = self.subtitle_pending = None
        self.history = HistoryWriter(host.report)
        self.session = StandardSession(host.accounts, history=self.history.save,
            next_loader=self.next_with_subtitle, open_next=self.open_next)
        parent = self
        class Player(xbmc.Player):
            def onPlayBackEnded(self):
                parent.event('ENDED')
            def onPlayBackStopped(self):
                parent.event('STOPPED')
            def onPlayBackError(self):
                parent.event('ERROR')
        self.player = Player()
        host.bind_owner(self.dispatch)

    def dispatch(self, body):
        operation = body.get('operation')
        if operation == 'select':
            self.clear_subtitle_state()
        if operation == 'subtitle_candidate':
            request = body['request_id']
            if self.session.current_request(request) and self.session.current['state'] == 'playing':
                row = self.session.current
                if row.get('subtitle'):
                    return dict(file=row['subtitle']['file'], url=row['data']['url'], request_id=request)
            return {}
        if operation == 'subtitle_start':
            request, data = body['request_id'], body['data']
            if not self.session.current_request(request) or data.get('_account') != self.session.current['account']:
                return {'state': 'stale'}
            self.subtitle_pending = dict(request_id=request, data=deepcopy(data),
                cancel=self.session.current['cancel'], deadline=time.monotonic() + 30)
            self._subtitles()
            return {'state': 'pending'}
        if operation == 'register':
            self._subtitles()
            body = deepcopy(body)
            row = self.session.current
            if row and body['request_id'] == row['request_id'] and row.get('subtitle'):
                if not body['data'].get('subtitles_path') and not body['data'].get('_manual_subtitles'):
                    body['data']['subtitles_path'] = [row['subtitle']['file']]
            result = self.session.dispatch(body)
            if result.get('accepted'):
                result['subtitles_path'] = body['data'].get('subtitles_path', [])
            return result
        return self.session.dispatch(body)

    def clear_subtitle_state(self):
        row = self.session.current
        if not row:
            return
        import xbmcgui
        window = xbmcgui.Window(10000)
        if window.getProperty('AM6B.SubtitleStateOwner') == row['request_id']:
            for key in ('AM6B.SubtitleStateOwner', 'AM6B.SubtitleState', 'bobbi.standard.subtitle'):
                window.clearProperty(key)

    def next_with_subtitle(self, current, cancelled):
        guard = lambda: cancelled() or not self.host.accounts.is_current(current['_account'])
        data = next_data(current, guard)
        if data and not guard() and not data.get('subtitles_path'):
            try:
                candidate = discover(data, self.host, time.monotonic() + 30, guard)
                if candidate and not guard():
                    data['subtitles_path'] = [candidate['file']]
            except (OSError, ValueError, RuntimeError):
                pass
        return data if not guard() else None

    def _subtitles(self):
        if self.subtitle_worker and not self.subtitle_worker.is_alive():
            self.subtitle_worker.join()
            job, self.subtitle_job, self.subtitle_worker = self.subtitle_job, None, None
            if (self.session.current_request(job['request_id']) and job.get('result')
                    and time.monotonic() < job['deadline']):
                row = self.session.current
                row['subtitle'] = job['result']
                # A stock player has no atomic user-intent check. Already
                # submitted files keep a late candidate, not an unscoped
                # setSubtitles call that could undo the user's manual Off.
                if row['state'] != 'selected':
                    import xbmcgui
                    window = xbmcgui.Window(10000)
                    window.setProperty('AM6B.SubtitleStateOwner', job['request_id'])
                    window.setProperty('AM6B.SubtitleState', '中文字幕候选已就绪 · 字幕菜单可选择')
                    window.setProperty('bobbi.standard.subtitle', job['result']['file'])
        if self.subtitle_worker is not None or self.subtitle_pending is None:
            return
        job, self.subtitle_pending = self.subtitle_pending, None
        if not self.session.current_request(job['request_id']):
            return
        self.subtitle_job = job
        def work():
            try:
                cancelled = lambda: job['cancel'].is_set() or not self.host.accounts.is_current(job['data']['_account'])
                job['result'] = discover(job['data'], self.host, job['deadline'], cancelled)
                if cancelled():
                    job['result'] = None
            except Exception:
                job['result'] = None
        self.subtitle_worker = Thread(target=work, name='bobbi-standard-subtitles', daemon=True)
        self.subtitle_worker.start()

    def event(self, kind):
        # Callback captures the association established by actual AV samples,
        # not whichever pending selection happens to exist when dequeued.
        try:
            self.events.put_nowait((self.bound, kind))
        except Full:
            self.session.retire('EVENT_OVERFLOW')

    def open_next(self, data):
        from bobbi_platform.kodi import standard_handoff
        from bobbi_platform.playback import selected_identity
        request = data['request_id']
        if self.player.isPlaying():
            return
        self.clear_subtitle_state()
        self.session.select(request, data['_account'])
        if not self.session.register(request, data)['accepted']:
            return
        identity = selected_identity(data['url'])
        standard_handoff(identity, -1, ready=lambda: self.session.current_request(request)
                         and not self.player.isPlaying()).submit(identity, data)

    def tick(self):
        self._subtitles()
        playing = self.player.isPlayingVideo()
        while True:
            try:
                request, kind = self.events.get_nowait()
            except Empty:
                break
            self.session.terminal(request, kind, playing)
        if playing:
            try:
                from bobbi_platform.standard_subtitle_ui import request_id
                request = request_id(self.player)
                if self.session.observe(request, self.player.getPlayingFile(),
                                        self.player.getTime(), self.player.getTotalTime()):
                    self.bound = request
                else:
                    self.bound = ''
            except RuntimeError:
                pass  # Opening/seeking is not evidence of end or error.
        self.session.tick(playing=self.player.isPlaying())
        if self.session.current and not self.session.current_request(self.session.current['request_id']):
            self.clear_subtitle_state()

    def close(self):
        self.clear_subtitle_state()
        self.session.close()
        self.history.close()
        if self.subtitle_worker:
            self.subtitle_worker.join(timeout=.1)
